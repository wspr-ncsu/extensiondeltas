inputArgs <- function(){
  args <- commandArgs(trailingOnly=TRUE)
  # print(args[1])
  print(args[2])
  # return()
  df1 <- read.table(args[1],  fill=TRUE, header=TRUE)
  df1
  args[1]
  # return()
  loadLibraries()

  factor <- 1
  minPer <- 10
  dir <- "./minus10/"
  calculate(df1, factor, minPer, dir)

  factor <- 1  
  minPer <- 30
  dir <- "./minus30/"
  calculate(df1, factor, minPer, dir)

  factor <- 0.9
  minPer <- 0
  dir <- "./percentMinus10/"
  calculate(df1, factor, minPer, dir)

  factor <- 0.7
  minPer <- 0  
  dir <- "./percentMinus30/"
  calculate(df1, factor, minPer, dir)

  factor <- 0.5
  minPer <- 0  
  dir <- "./percentMinus50/"  

  calculate(df1, factor, minPer, dir)
  # raw_input("Please type enter...")
}

loadLibraries <- function(){
    library(anomalize) #tidy anomaly detectiom
    library(tidyverse) #tidyverse packages like dplyr, ggplot, tidyr
    library(ramify)  
}

calculate <- function(Comb, factor, minPer, dir){
    btc1 <-  as.data.frame.matrix(Comb)
    minPer <- minPer
    btc <- tail(btc1, nrow(btc1)*factor - minPer )
    btc <- btc[order(as.Date(btc$date, format="%m/%d/%Y")),]
    dates <- as.Date(btc[,1], "%m/%d/%Y") 
    btc_ts <- as.data.frame.matrix(btc) %>% as.tibble() %>% mutate(date = dates)
    btc_ts <- btc_ts[,c(2, 1)]
    args <- commandArgs(trailingOnly=TRUE)
    dir <- dir
    string <- paste(c(dir, toString(args[2]), ".csv"), collapse="")    
    result <- btc_ts %>% 
      time_decompose(Score) %>%
      anomalize(remainder) %>%
      time_recompose() %>% filter(anomaly == 'Yes') 
    write.csv(result, file=string)
}

popUp <- function(){
    prompt  <- "hit spacebar to close plots"
    extra   <- "some extra comment"
    capture <- tcltk::tk_messageBox(message = prompt, detail = extra)    
}

tryCatch({
    inputArgs()
  }, error=function(e){})


